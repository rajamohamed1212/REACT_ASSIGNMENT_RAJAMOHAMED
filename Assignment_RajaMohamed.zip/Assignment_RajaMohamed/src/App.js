import React, { Component } from 'react';
import { Route, Switch } from "react-router-dom";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { withRouter } from "react-router-dom";
import * as productActions from "./actionCreators/products";
import ProductList from "./components/productList";
import AddProduct from './components/addProduct';
import EditProduct from './components/editProduct';
class App extends Component {
  //component will mount
  componentWillMount() {
    this.props.actions.getProducts();
  }

  //delete handle 
  handleDelete = (prod) => {
    this.props.actions.deleteProduct(prod);
    window.location.href = "/";
  }
  // handle OnChange
  handleOnChangeAdd = (e) => {
    console.log("onchange")
    const name = e.target.name;
    const value = e.target.value;
    const addItem = {};
    addItem[name] = value;
    this.props.actions.addInputChange(addItem);
  }
  //handle click
  handleClickAdd = (productAdd) => {
    this.props.actions.addProduct(productAdd);
    window.location.href = "/";
  }

  //edit handle 
  handleEdit = (prod) => {
    this.props.actions.editProduct(prod);
  }

  //edit changes 
  handleEditChanges = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    const editItem = {};
    editItem[name] = value;
    this.props.actions.editInputChange(editItem);
  }

  //handle edit click 
  handleClickEdit = (editProducts) => {
    this.props.actions.editSuccessProduct(editProducts);
    window.location.href = "/";
  }

  //pagination
  handlePagination = (num) => {
    this.props.actions.paginate(num);
  }

  //for modal
  handleModal = () => {
    this.props.actions.modalToggle();
  }
  render() {
    return (
      <div>
        <Switch>
          <Route
            exact
            path="/"
            render={props =>
              <ProductList
                {...props}
                products={this.props.productsList}
                onDelete={this.handleDelete}
                onEdit={this.handleEdit}
                handlePaginateClick={this.handlePagination}
                currentPageNum={this.props.currentPageNumber}
                contentNumber={this.props.pageContentNumber}
                modalShow={this.props.modalStatus}
                modalClick={this.handleModal}
              />
            }
          />
          <Route
            path="/add-product"
            render={props =>
              <AddProduct
                {...props}
                tempProd={this.props.productAdd}
                onChangeAdd={this.handleOnChangeAdd}
                onClickAdd={this.handleClickAdd}
              />
            }
          />
          <Route
            path="/edit-product"
            render={props =>
              <EditProduct
                {...props}
                editProducts={this.props.editProd}
                onChangeEdit={this.handleEditChanges}
                onClickEdit={this.handleClickEdit}
              />
            }
          />
        </Switch>
      </div>
    );
  }
}

//map state to props
function mapStateToProps(state) {
  return {
    productsList: state.products,
    productAdd: state.addProduct,
    editProd: state.editProduct,
    currentPageNumber: state.currentPage,
    pageContentNumber: state.contentPerPage,
    modalStatus: state.modalOpened
  };
}
//dispatch 
function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(productActions, dispatch)
  };
}
export default withRouter(connect(mapStateToProps, mapDispatchToProps)(App));
